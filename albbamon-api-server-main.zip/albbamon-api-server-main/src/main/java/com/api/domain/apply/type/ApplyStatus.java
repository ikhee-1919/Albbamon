package com.api.domain.apply.type;

public enum ApplyStatus {
    WAITING,
    PASSED,
    FAILED
}
