package com.api.domain.user.dto.request;

public record UserRequestDto(
        Long userId
) {
}
